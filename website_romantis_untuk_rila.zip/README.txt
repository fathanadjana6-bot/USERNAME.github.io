WEBSITE ROMANTIS UNTUK RILA

File utama:
- index.html

Cara menjalankan:
1. Buka index.html di Chrome untuk melihat website.
2. Upload index.html ke GitHub Pages, Cloudflare Pages, atau hosting lain.
3. Untuk domain sendiri, hubungkan custom domain ke hosting.

Semua desain dan animasi ada di dalam index.html sehingga mudah diedit dari HP.
